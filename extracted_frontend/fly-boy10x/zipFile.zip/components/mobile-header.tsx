'use client';

import { useState } from 'react';
import { ChevronLeft, Menu, MessageCircle } from 'lucide-react';
import RegisterModal from '@/components/modals/register-modal';
import DepositModal from '@/components/modals/deposit-modal';
import NotificationsModal from '@/components/modals/notifications-modal';

interface MobileHeaderProps {
  balance: number;
}

export default function MobileHeader({ balance }: MobileHeaderProps) {
  const [showRegister, setShowRegister] = useState(false);
  const [showDeposit, setShowDeposit] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);

  return (
    <>
      <header className="bg-slate-950 border-b border-slate-800 px-3 py-2 md:hidden">
        <div className="flex items-center justify-between gap-2">
          {/* Left: Back Arrow + Balance Box */}
          <div className="flex items-center gap-2">
            <button className="p-1 hover:bg-slate-800 rounded transition">
              <ChevronLeft className="w-5 h-5 text-slate-400" />
            </button>
            <div className="border border-lime-500 rounded px-2 py-1 min-w-max">
              <div className="text-xs text-lime-400 font-semibold">NGN</div>
              <div className="text-sm font-bold text-lime-400">{(balance).toFixed(2)}</div>
            </div>
          </div>

          {/* Center: Logo */}
          <div className="text-center">
            <div className="text-xs font-bold tracking-tight">
              <span className="text-red-500">Fly</span>
              <span className="text-lime-400">Boy</span>
              <span className="text-red-500">10x</span>
            </div>
          </div>

          {/* Right: Icons */}
          <div className="flex items-center gap-1">
            {/* Chat Icon */}
            <button className="p-1 hover:bg-slate-800 rounded transition">
              <MessageCircle className="w-4 h-4 text-lime-400" />
            </button>

            {/* Menu */}
            <button className="p-1 hover:bg-slate-800 rounded transition">
              <Menu className="w-5 h-5 text-slate-400" />
            </button>
          </div>
        </div>
      </header>

      {/* Modals */}
      <RegisterModal isOpen={showRegister} onClose={() => setShowRegister(false)} />
      <DepositModal isOpen={showDeposit} onClose={() => setShowDeposit(false)} />
      <NotificationsModal isOpen={showNotifications} onClose={() => setShowNotifications(false)} />
    </>
  );
}
