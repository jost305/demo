'use client';

import { useState, useEffect } from 'react';
import GameChart from '@/components/game-chart';

const PREVIOUS_ROUNDS = [1.09, 2.00, 1.02, 1.32, 5.53, 3.90];

interface MobileGameViewProps {
  balance: number;
  setBalance: (balance: number) => void;
}

export default function MobileGameView({ balance, setBalance }: MobileGameViewProps) {
  const [displayMultiplier, setDisplayMultiplier] = useState(5.53);
  const [bet1Amount, setBet1Amount] = useState(10.00);
  const [bet2Amount, setBet2Amount] = useState(50.00);
  const [bet1AutoBet, setBet1AutoBet] = useState(false);
  const [bet1AutoCashout, setBet1AutoCashout] = useState(false);
  const [bet2AutoBet, setBet2AutoBet] = useState(false);
  const [bet2AutoCashout, setBet2AutoCashout] = useState(false);
  const [gameActive, setGameActive] = useState(true);

  // Animate multiplier
  useEffect(() => {
    if (!gameActive) return;
    const interval = setInterval(() => {
      setDisplayMultiplier(prev => {
        const newVal = prev + (Math.random() * 0.5 - 0.1);
        return Math.min(newVal, 150);
      });
    }, 150);
    return () => clearInterval(interval);
  }, [gameActive]);

  return (
    <div className="flex-1 flex flex-col bg-slate-950 overflow-y-auto scrollbar-hide mb-16">
      {/* Previous Rounds */}
      <div className="px-2 py-2 border-b border-lime-500/30 flex gap-1 overflow-x-auto scrollbar-hide">
        {PREVIOUS_ROUNDS.map((round, i) => (
          <div
            key={i}
            className="flex-shrink-0 px-2 py-1 bg-slate-800 rounded text-xs text-cyan-300 font-semibold whitespace-nowrap"
          >
            {round}x
          </div>
        ))}
        <button className="flex-shrink-0 px-2 py-1 text-slate-400 text-xs font-semibold">Round History ▼</button>
      </div>

      {/* Game Chart Container - Lime Green Border */}
      <div className="flex-1 flex flex-col px-2 py-2 m-2 border border-lime-400 rounded bg-slate-900/50 min-h-96">
        {/* Chart Area */}
        <div className="flex-1 flex items-center justify-center">
          <GameChart />
        </div>

        {/* Multiplier Display */}
        <div className="text-center mb-2">
          <div className="text-4xl font-black text-lime-400 transition-all duration-100">
            {displayMultiplier.toFixed(2)}<span className="text-2xl">x</span>
          </div>
          <div className="text-xs text-lime-400 font-semibold tracking-wide">FLEW HIGH!</div>
        </div>
      </div>

      {/* Betting Controls - Two Cards Stacked */}
      <div className="px-2 pb-2 space-y-2">
        {/* Bet Card 1 */}
        <div className="border border-lime-400/50 rounded bg-slate-900/80 p-2">
          <div className="flex justify-between items-center mb-1">
            <div className="flex items-center gap-1">
              <input
                type="checkbox"
                checked={bet1AutoBet}
                onChange={(e) => setBet1AutoBet(e.target.checked)}
                className="w-3 h-3 accent-lime-400"
              />
              <span className="text-xs text-slate-400">Auto Bet</span>
            </div>
            <div className="flex items-center gap-1">
              <input
                type="checkbox"
                checked={bet1AutoCashout}
                onChange={(e) => setBet1AutoCashout(e.target.checked)}
                className="w-3 h-3 accent-lime-400"
              />
              <span className="text-xs text-slate-400">Auto Cashout</span>
            </div>
          </div>

          <div className="flex justify-between text-xs text-slate-500 mb-1">
            <span>Min : 10</span>
            <span>Max : 5000000</span>
          </div>

          <div className="flex gap-2 items-center mb-2">
            <button className="px-2 py-1 bg-slate-800 hover:bg-slate-700 rounded text-white">−</button>
            <input
              type="number"
              value={bet1Amount.toFixed(2)}
              onChange={(e) => setBet1Amount(Number(e.target.value))}
              className="flex-1 bg-transparent text-center text-lg font-bold text-white outline-none"
            />
            <button className="px-2 py-1 bg-slate-800 hover:bg-slate-700 rounded text-white">+</button>
          </div>

          <div className="flex gap-1 mb-2">
            {[100, 200, '1K'].map(amt => (
              <button
                key={amt}
                onClick={() => setBet1Amount(typeof amt === 'string' ? 1000 : amt)}
                className="flex-1 py-0.5 bg-slate-800 hover:bg-slate-700 rounded text-xs font-semibold text-slate-300"
              >
                {amt}
              </button>
            ))}
          </div>

          <button className="w-full py-2 bg-lime-500 text-black font-bold rounded hover:bg-lime-400 transition text-sm">
            BET<br/><span className="text-xs">NGN {bet1Amount.toFixed(2)}</span>
          </button>
        </div>

        {/* Bet Card 2 */}
        <div className="border border-lime-400/50 rounded bg-slate-900/80 p-2">
          <div className="flex justify-between items-center mb-1">
            <div className="flex items-center gap-1">
              <input
                type="checkbox"
                checked={bet2AutoBet}
                onChange={(e) => setBet2AutoBet(e.target.checked)}
                className="w-3 h-3 accent-lime-400"
              />
              <span className="text-xs text-slate-400">Auto Bet</span>
            </div>
            <div className="flex items-center gap-1">
              <input
                type="checkbox"
                checked={bet2AutoCashout}
                onChange={(e) => setBet2AutoCashout(e.target.checked)}
                className="w-3 h-3 accent-lime-400"
              />
              <span className="text-xs text-slate-400">Auto Cashout</span>
            </div>
          </div>

          <div className="flex justify-between text-xs text-slate-500 mb-1">
            <span>Min : 10</span>
            <span>Max : 5000000</span>
          </div>

          <div className="flex gap-2 items-center mb-2">
            <button className="px-2 py-1 bg-slate-800 hover:bg-slate-700 rounded text-white">−</button>
            <input
              type="number"
              value={bet2Amount.toFixed(2)}
              onChange={(e) => setBet2Amount(Number(e.target.value))}
              className="flex-1 bg-transparent text-center text-lg font-bold text-white outline-none"
            />
            <button className="px-2 py-1 bg-slate-800 hover:bg-slate-700 rounded text-white">+</button>
          </div>

          <div className="flex gap-1 mb-2">
            {[100, 200, '1K'].map(amt => (
              <button
                key={amt}
                onClick={() => setBet2Amount(typeof amt === 'string' ? 1000 : amt)}
                className="flex-1 py-0.5 bg-slate-800 hover:bg-slate-700 rounded text-xs font-semibold text-slate-300"
              >
                {amt}
              </button>
            ))}
          </div>

          <button className="w-full py-2 bg-lime-500 text-black font-bold rounded hover:bg-lime-400 transition text-sm">
            BET<br/><span className="text-xs">NGN {bet2Amount.toFixed(2)}</span>
          </button>
        </div>

        {/* Bottom Controls */}
        <div className="flex gap-2 px-1 py-1 text-xs text-slate-400">
          <button className="flex items-center gap-1">🔊 Sound</button>
          <button className="flex items-center gap-1">📳 Vibration</button>
          <button className="ml-auto flex items-center gap-1">✓ Probably Fair &gt;</button>
        </div>
      </div>
    </div>
  );
}
